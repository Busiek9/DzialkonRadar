#include "RadarMap.h"
#include <Arduino.h>

RadarMap::RadarMap(int dataPin, int clkPin, int csPin, int numDevices = 1)
{
	size = 8;
	lastIndex = size - 1;
    RadarMap::numDevices = numDevices;

    lc = new LedControl(dataPin, clkPin, csPin, numDevices);

    for (int i = 0; i < numDevices; i++)
    {
        lc->shutdown(i, false);
        lc->setIntensity(i, 15);
        lc->clearDisplay(i);
    }
}

void RadarMap::SetPoint(int x, int y, int quarter)
{
    Serial.print("Set point (");
    Serial.print(x);
    Serial.print(",");
    Serial.print(y);
    Serial.println(")");

	if (quarter == 0)
	{
		SetWholeMap();
	}
	else if (quarter == 1)
	{
        lc->setLed(0, y, lastIndex - x, true);
	}
	else if (quarter == 2)
	{
        lc->setLed(0, y + lastIndex, lastIndex - x, true);
	}
	else if (quarter == 3)
	{
        lc->setLed(0, -y, lastIndex + x, true);
	}
	else if (quarter == 4)
	{
        lc->setLed(0, lastIndex - y, lastIndex + x, true);
	}
}

int RadarMap::SetSegmentPoints(int x, int y)
{
    ClearMap();

    int quarter = CalculateQuarter(x, y);

    int xMin = min(0, x), xMax = max(0, x);
    int yMin = min(0, y), yMax = max(0, y);

    double a = y / (double)x;

    if (abs(x) > abs(y))
    {
        for (int i = xMin; i < xMax + 1; i++)
        {
            int nearestY = yMin;
            double calculatedY = i * a;
            double delta = abs(calculatedY - nearestY);
            for (int j = yMin + 1; j < yMax + 1; j++)
            {
                double currentDelta = abs(calculatedY - j);

                if (currentDelta < delta)
                {
                    delta = currentDelta;
                    nearestY = j;
                }
            }

            SetPoint(i, nearestY, quarter);
        }
    }
    else
    {
        for (int i = yMin; i < yMax + 1; i++)
        {
            int nearestX = xMin;
            double calculatedX = i / a;
            double delta = abs(calculatedX - nearestX);
            for (int j = xMin + 1; j < xMax + 1; j++)
            {
                double currentDelta = abs(calculatedX - j);

                if (currentDelta < delta)
                {
                    delta = currentDelta;
                    nearestX = j;
                }
            }

            SetPoint(nearestX, i, quarter);
        }
    }

    return quarter;
}

int RadarMap::CalculateQuarter(int x, int y)
{
    if (x == 0 && y == 0)
    {
        // destination point reached, light all leds on all displays
        return 0;
    }

    if (x >= 0 && y >= 0)
    {
        return 1;
    }

    if (x > 0 && y < 0)
    {
        return 2;
    }

    if (x <= 0 && y <= 0)
    {
        return 3;
    }

    if (x < 0 && y > 0)
    {
        return 4;
    }

    return -1;
}

void RadarMap::ClearMap()
{
    for (int i = 0; i < numDevices; i++)
    {
        lc->clearDisplay(i);
    }
}

void RadarMap::SetWholeMap()
{
    for (int i = 0; i < numDevices; i++)
    {
        for (int j = 0; j < size; j++)
        {
            lc->setRow(i, j, true);
        }
    }
}