#pragma once
#include <LedControl.h>

class RadarMap
{
private:
	int size;
	int lastIndex;
	int numDevices;
	LedControl* lc;

	void SetPoint(int x, int y, int quarter);
	int CalculateQuarter(int x, int y);
	void SetWholeMap();
	void ClearMap();

public:
	//bool map[8][8];
	RadarMap(int dataPin, int clkPin, int csPin, int numDevices = 1);
	int SetSegmentPoints(int x, int y);
};

